"use client"

import { useRef } from "react"
import { motion, useInView } from "framer-motion"
import { User, Code, Briefcase, GraduationCap } from "lucide-react"

export default function About() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.3 })

  const aboutItems = [
    {
      icon: <User className="h-6 w-6" />,
      title: "Who I Am",
      description: "A passionate frontend developer with a keen eye for design and user experience.",
    },
    {
      icon: <Code className="h-6 w-6" />,
      title: "What I Do",
      description: "Create responsive, interactive, and visually appealing web applications using modern technologies.",
    },
    {
      icon: <Briefcase className="h-6 w-6" />,
      title: "Experience",
      description: "Worked on various projects ranging from simple websites to complex web applications.",
    },
    {
      icon: <GraduationCap className="h-6 w-6" />,
      title: "Education",
      description: "Continuously learning and improving my skills through courses, tutorials, and hands-on projects.",
    },
  ]

  return (
    <section id="about" className="py-20 bg-white dark:bg-slate-800">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-slate-800 dark:text-white mb-4">About Me</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-blue-600 to-indigo-600 mx-auto mb-6"></div>
          <p className="max-w-2xl mx-auto text-slate-600 dark:text-slate-300 text-lg">
            I'm a frontend developer passionate about creating beautiful and functional web experiences. I specialize in
            building responsive websites and applications using modern technologies.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {aboutItems.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.6, delay: 0.2 + index * 0.1 }}
              className="bg-slate-50 dark:bg-slate-700 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300"
            >
              <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full flex items-center justify-center text-white mb-4">
                {item.icon}
              </div>
              <h3 className="text-xl font-semibold text-slate-800 dark:text-white mb-2">{item.title}</h3>
              <p className="text-slate-600 dark:text-slate-300">{item.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

